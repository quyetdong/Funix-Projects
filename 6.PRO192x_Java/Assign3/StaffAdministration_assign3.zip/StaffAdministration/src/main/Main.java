package main;

/* 
 * Run program
 */

public class Main {
	public static void main(String[] args) {
		AdminData employee = new AdminData();
		
		employee.inputInfor();
		employee.arrangeInfor();
		employee.printInfor();
		employee.searchInfor();
	}
}
