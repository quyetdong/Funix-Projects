package main;

import java.util.Scanner;

/* 
 * Interface
 * Specify behaviors in data management
 */

public interface ProceedData {
	public void inputInfor(Scanner sc);
	public int searchInfor(Scanner sc);
	public void printInfor();
}
