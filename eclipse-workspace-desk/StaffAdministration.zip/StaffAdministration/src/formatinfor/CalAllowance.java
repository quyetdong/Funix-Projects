package formatinfor;

/**
 * Calculate and return salary for an employee
 */

public interface CalAllowance {
	public void calAllowance(String level);
}
